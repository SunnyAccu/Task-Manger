const mongoose=require('mongoose')
const connectsrting='mongodb+srv://sunny:Sunn30@cluster0.7yosyw9.mongodb.net/03-Task-Manager?retryWrites=true&w=majority'

mongoose.connect(connectsrting,{
    useNewUrlParser:true,
    useUnifiedTopology:true,
    useFindAndModify:false
}).then(()=> console.log('connected to db')).catch((err)=>(err))