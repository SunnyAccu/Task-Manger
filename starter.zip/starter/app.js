require('./db/conn')
const express=require('express')
const app=express()
const port=process.env.PORT || 3000
const tasks=require('./routes/task')

app.use(express.static('./public'))

app.use(express.json())

app.get('/',(req,res)=>{
    res.send("Task manager")
})

app.use('/api/v1/tasks',tasks)



app.get('/api/v1/tasks',tasks)
app.post('/api/v1/tasks',tasks)
app.get('/api/v1/tasks/:id',tasks)
app.patch("/api/v1/tasks/:id",tasks)
app.delete("/api/v1/tasks/:id",tasks)

app.listen(port,()=>{
    console.log(`the server is running ${port}`)
})
